const backendUrl = "http://localhost:5000/";

export { backendUrl };
