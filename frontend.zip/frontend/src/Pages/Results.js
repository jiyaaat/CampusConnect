import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { backendUrl } from "../exports";
import Navbar from "../Components/Navbar";

const Results = () => {
  const { searchTerm } = useParams();
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchResults = async () => {
      try {
        const response = await fetch(
          `${backendUrl}suggestions/search?term=${searchTerm}`
        );
        const data = await response.json();
        setResults(data.results);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching search results:", error);
        setLoading(false);
      }
    };

    fetchResults();
  }, [searchTerm]);

  return (
    <>
      <Navbar />
      <div className="results-page">
        <h2>Search Results for "{searchTerm}"</h2>
        {loading ? (
          <p>Loading...</p>
        ) : results.length === 0 ? (
          <p>No results found.</p>
        ) : (
          <div className="results-container">
            {results &&
              results.map((result) => (
                <div key={result.id} className="result-item">
                  <p>{result.name}</p>
                  <p>{result.bio}</p>
                  <p>Age: {result.age}</p>
                  <p>Gender: {result.gender}</p>
                  <p>Location: {result.location}</p>
                  <p>Interests: {result.interests.join(", ")}</p>
                </div>
              ))}
          </div>
        )}
      </div>
    </>
  );
};

export default Results;
